export const customTheme = {
  white: '#fff',
  darkBlue: '#3c5aa6',
  yellowShadow: '#c7a008',
  lightBlue: '#2a75bb',
  yellow: '#FFCC00',
  orange: '#FF6600',
  grey: '#333',
};

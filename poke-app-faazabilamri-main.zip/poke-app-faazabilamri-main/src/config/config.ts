const config = {
  apiBaseUrl: 'https://pokeapi.co/api/',
  apiVersion: 'v2',
};

export default config;

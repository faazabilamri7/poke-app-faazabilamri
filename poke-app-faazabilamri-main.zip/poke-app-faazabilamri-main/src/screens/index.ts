import HomePage from './HomePage/HomePage';
import DetailPokemonPage from './DetailPage/DetailPage';
import ComparePage from './ComparePage/ComparePage';

export {HomePage, DetailPokemonPage, ComparePage};
